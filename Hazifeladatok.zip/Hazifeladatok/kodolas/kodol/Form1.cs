﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kodol
{
    public partial class Form1 : Form
    {
        TextBox szoveg;
        Label szovegkiir;
        Button gomb;
        
        public Form1()
        {
            InitializeComponent();
        }
        private string szovegbeker()
        {       
            string nyilt_szoveg = szoveg.Text;
            return nyilt_szoveg;
        }
        private string szovegAtalakit() 
        { 
            string szoveg = szovegbeker();
            char[] betuk = szoveg.ToCharArray();
            for (int i = 0; i < betuk.Length; i++)
            {
                if (betuk[i] == 'á') betuk[i] = 'a';
                else if (betuk[i] == 'é') betuk[i] = 'e';
                else if (betuk[i] == 'ú') betuk[i] = 'u';
                else if (betuk[i] == 'ü') betuk[i] = 'u';
                else if (betuk[i] == 'ű') betuk[i] = 'u';
                else if (betuk[i] == 'ő') betuk[i] = 'o';
                else if (betuk[i] == 'ö') betuk[i] = 'o';
                else if (betuk[i] == 'ó') betuk[i] = 'o';
                else if (betuk[i] == 'í') betuk[i] = 'i';
            }
            
            return new string (betuk);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            szoveg = new TextBox()
            {
                Parent  = this,
                Location = new Point(20, 20),
                Size = new Size(100,20),
                Text = ""
            
            };
            szovegkiir = new Label()
            {
                Parent = this,
                Location = new Point(20, 70),
                Size = new Size(100, 20),
                Text = ""
            };
            gomb = new Button() 
            {
                Parent = this,
                Location = new Point(20, 100),
                Size = new Size(80, 40),
                Text = "Titkosít"
            };
            gomb.Click += Gomb_Click;

        }

        private void Gomb_Click(object sender, EventArgs e)
        {
            string atalakitottszoveg = szovegAtalakit();
            szovegkiir.Text = atalakitottszoveg.ToUpper();
            
        }
    }
}
