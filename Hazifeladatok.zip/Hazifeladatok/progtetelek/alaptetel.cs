﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p14_alaptetelek {
    class alaptetel {
        #region Private mezők
        int ertek;
        int[] A_tomb, B_tomb; //private mezők
        #endregion

        #region Konstruktorok
        public alaptetel(int[] T) { A_tomb = T; }
        public alaptetel(int[] T, int Szam) { A_tomb = T; ertek = Szam; }
        public alaptetel(int[] T, int[] Z) { A_tomb = T; B_tomb = Z; }
        #endregion
        #region Függvények
        public int Megszamlalas() {
            int N = 0; //ennyszier szerepel az adott érték
            for (int i = 0; i < A_tomb.Length; i++) {
                if (A_tomb[i] == ertek) N++;
            }
            return N;
        }
        public int Osszegzes() {
            int Osszeg = 0;
            for (int i = 0; i < A_tomb.Length; i++) {
                Osszeg += A_tomb[i];
            }
            return Osszeg;
        }
        public bool Eldontes() {
            for (int i = 0; i < A_tomb.Length; i++) {
                if (A_tomb[i] == ertek) return true;
            }
            return false;
        }
        public int Kivalasztas() { //A hívó fél (Form1) fogja az Eldöntést meghívni!!!
                for (int i = 0; i < A_tomb.Length; i++) {
                    if (A_tomb[i] == ertek) return i;
                }
            return -1;
        }
        public int Linearis_Kereses() {
            for (int i = 0; i < A_tomb.Length; i++) {
                if (A_tomb[i] == ertek) return i;
            }
            return -1;
        }
        public int Binaris_Kereses() {
            Array.Sort(A_tomb);
            int Also = 0, Felso = A_tomb.Length - 1, kozepso = (Also + Felso) / 2;

            while (Also <= Felso && ertek != A_tomb[kozepso]) {
                if (A_tomb[kozepso] < ertek) Also = kozepso + 1;
                else Felso = kozepso - 1;
                kozepso = (Also + Felso) / 2;
            }
            if (Also > Felso && ertek != A_tomb[kozepso]) return -1;
            else return kozepso;
        }
        public int[] Unio() {
            List<int> U = new List<int>();
            for (int i = 0; i < A_tomb.Length; i++) {
                U.Add(A_tomb[i]);
            }
            for (int i = 0; i < B_tomb.Length; i++) {
                bool Bennevan = false;
                for (int j = 0; j < U.Count; j++) {
                    if (B_tomb[i] == U[j]) Bennevan = true;
                }
                if (!Bennevan) U.Add(B_tomb[i]);
            }
            return U.ToArray();
        }
        public int[] Metszet() {
            List<int> M = new List<int>();
            for (int i = 0; i < A_tomb.Length; i++) {
                for (int j = 0; j < B_tomb.Length; j++) {
                    if (A_tomb[i] == B_tomb[j]) M.Add(A_tomb[i]);
                }
            }
            return M.ToArray(); //a hívó félnél meg kell vizsgálni, hogy nem üreshalmaz-e?
        }
        public int[] Kulonbseg() { //  mindenféleképpen az A\B-t állítjuk elő!
            List<int> K = new List<int>();
            for (int i = 0; i < A_tomb.Length; i++) {
                bool Bennevan = false;
                for (int j = 0; j < B_tomb.Length; j++) {
                    if (A_tomb[i] == B_tomb[j]) Bennevan = true;
                }
                if (!Bennevan) K.Add(A_tomb[i]);
            }
            return K.ToArray();
        }
        public int[][] Descartes() {// mindenképpen AxB -t állítjuk elő!
            List<int[]> D = new List<int[]>();
            for (int i = 0; i < A_tomb.Length; i++) {
                for (int j = 0; j < B_tomb.Length; j++) {
                    /*int[] tombocske = { A_tomb[i], B_tomb[j] };
                    D.Add(tombocske);*/
                    D.Add(new int[] { A_tomb[i], B_tomb[j] });
                }
            }
            return D.ToArray();
        }
        public int[] Egyszeru_Cseres() {
            int csere = 0;
            for (int i = 0; i < A_tomb.Length - 1; i++) {
                for (int j = i+1; j < A_tomb.Length; j++) {
                    if (A_tomb[i] > A_tomb[j]) {
                        csere = A_tomb[i];
                        A_tomb[i] = A_tomb[j];
                        A_tomb[j] = csere;
                    }
                }
            }
            return A_tomb;
        }
        public int[] Buborek() {
            int csere = 0;
            for (int i = A_tomb.Length - 1; i > 0 ; i--) {
                for (int j = 0; j < i; j++) {
                    if (A_tomb[j] > A_tomb[j+1]) {
                        csere = A_tomb[j];
                        A_tomb[j] = A_tomb[j + 1];
                        A_tomb[j + 1] = csere;
                    }
                }
            }
            return A_tomb;
        }
        public int[] MinMax() {
            int csere = 0, akt_index = 0;
            for (int i = 0; i < A_tomb.Length - 1; i++) {
                akt_index = i;
                for (int j = i+1; j < A_tomb.Length; j++) {
                    if (A_tomb[akt_index] > A_tomb[j]) akt_index = j;
                }
                csere = A_tomb[i];
                A_tomb[i] = A_tomb[akt_index];
                A_tomb[akt_index] = csere;
            }
            return A_tomb;
        }
        public int[] Shell() {
            int csere = 0, tavolsag = A_tomb.Length / 3, j = 0;
            while (tavolsag > 0) {
                for (int i = 0; i < A_tomb.Length; i++) {
                    j = i;
                    csere = A_tomb[i];
                    while (j >= tavolsag && A_tomb[j - tavolsag] > csere) {
                        A_tomb[j] = A_tomb[j - tavolsag];
                        j = j - tavolsag;
                    }
                    A_tomb[j] = csere;
                }
                if (tavolsag / 2 != 0) tavolsag = tavolsag / 2;
                else if (tavolsag == 1) tavolsag = 0;
                else tavolsag = 1;
            }
            return A_tomb;
        }
        #endregion
    }
}
