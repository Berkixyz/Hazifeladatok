﻿using p14_alaptetelek;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace progtetelek
{
    public partial class Form1 : Form
    {
        MenuStrip MM=new MenuStrip();
        string[] MenuFeliratok = { "Adatok megadása", "alaptételek", "Kilépés" };
        string[] AlmenuFeliratok = { "Megszámlálás", "Összegzés", "Eldöntés", "Kiválasztás", "Lineáris-keresés", "Bináris keresés", "Unio", "Metszet", "Különbség", "Descartes", "Egyszerű-cserés", "Buborés", "MinMax", "Shell beszúró rendezés",};
        ToolStripMenuItem[] FomenuPontok = new ToolStripMenuItem[3];
        string MitOlvasokBe = "";
        string MelyikTetel = "";
        ToolTip TT = new ToolTip()
        {
            AutomaticDelay = 500,
            IsBalloon = true,
            ReshowDelay = 900,
            AutoPopDelay = 3000,
        };
        NumericUpDown ElsoElemszam, MasodikElemszam, Ertek;
        NumericUpDown[] Tomb_e, Tomb_m;
        Button Tomb_e_mehet, Tomb_e_elkeszult, Tomb_m_mehet, Tomb_m_elkeszult, Ertek_mehet, Ok_gomb;
        Label Kiiras;
            

        public Form1()
        {
            InitializeComponent();
            //this.FormBorderStyle = FormBorderStyle.None;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Font = new Font("Garamond", 16f);
            Size = new Size(700, 400);
            //FormBorderStyle = FormBorderStyle.None;
            
            //this.Menu=MM;
            //MenuItem[] FoMenupontok = new MenuItem[3];
            //for (int i = 0; i < FoMenupontok.Length; i++)
            //{
            //    FoMenupontok[i] = new MenuItem();
            //    FoMenupontok[i].Text = MenuFeliratok[i];
            //    FoMenupontok[i].Click += Fomenu_Click;
            //}
            //MM.MenuItems.AddRange(FoMenupontok);
            MM.BackColor = Color.FromArgb(100, 200, 100);
            MM.ForeColor= Color.FromArgb(155, 55, 155);
            MM.Text = "Ez itt a főmenü";
            MM.Font = new Font("Garamond",18f);
            MM.Dock = DockStyle.Top;
            FomenuPontok = new ToolStripMenuItem[3];
            for (int i = 0; i < 3; i++)
            {
                FomenuPontok[i] = new ToolStripMenuItem()
                {
                    Text = MenuFeliratok[i],
                    ForeColor = Color.FromArgb(100, 200, 100),
                    BackColor = Color.Black
                };
                FomenuPontok[i].Click += FomenuPont_Click;
                MM.Items.Add(FomenuPontok[i]);
            }
            FomenuPontok[0].Enabled = false;
            foreach (var felirat in AlmenuFeliratok)
            {
                ToolStripMenuItem MP = new ToolStripMenuItem(felirat);
                MP.Click += Almenu_Click;
                FomenuPontok[1].DropDownItems.Add(MP);
            }
            this.MainMenuStrip= MM;
            Controls.Add(MM);
        }

    private void Almenu_Click(object sender, EventArgs e)
        {
            var aktualis = sender as ToolStripMenuItem;
            MelyikTetel = aktualis.Text;
            switch (aktualis.Text)
            {
                case "Megszámlálás": MitOlvasokBe = "té"; AdatokBeolvasasa(); break;
                case "Összegzés": MitOlvasokBe = "t"; AdatokBeolvasasa(); break;
                case "Eldöntés": MitOlvasokBe = "té"; AdatokBeolvasasa(); break;
                case "Kiválasztás": MitOlvasokBe = "té"; AdatokBeolvasasa(); break;
                case "Lineáris-keresés": MitOlvasokBe = "té"; AdatokBeolvasasa(); break;
                case "Bináris keresés": MitOlvasokBe = "té"; AdatokBeolvasasa(); break;
                case "Unio": MitOlvasokBe = "h"; AdatokBeolvasasa(); break;
                case "Metszet": MitOlvasokBe = "h"; AdatokBeolvasasa(); break;
                case "Különbség": MitOlvasokBe = "h"; AdatokBeolvasasa(); break;
                case "Descartes": MitOlvasokBe = "h"; AdatokBeolvasasa(); break;
                case "Egyszerű-cserés": MitOlvasokBe = "t"; AdatokBeolvasasa(); break;
                case "Buborés": MitOlvasokBe = "t"; AdatokBeolvasasa(); break;
                case "MinMax": MitOlvasokBe = "t"; AdatokBeolvasasa(); break;
                case "Shell beszúró rendezés": MitOlvasokBe = "t"; AdatokBeolvasasa(); break;
                default:Application.Exit();
                    break;
            }
        }
        private void AdatokBeolvasasa()
        {
            FomenuPontok[1].Enabled = false;
            FomenuPontok[0].Enabled = true;
            if (MitOlvasokBe=="t")
            {
                ElsoElemszam = new NumericUpDown()
                {
                    Parent = this,
                    Location = new Point(20, 50),
                    Minimum = 3,
                    Maximum = 15,
                };
                TT.SetToolTip(ElsoElemszam, "Add meg a tömb elemszámát!");
                Tomb_e_mehet = new Button()
                {
                    Parent = this,
                    Location = new Point(200, 50),
                    Size = new Size(300, 30),
                    Text = "Kérem a tömböt!"
                };
                Tomb_e_mehet.Click += (s,e) =>
                {
                    Tomb_e_mehet.Enabled = false;
                    Tomb_e = new NumericUpDown[(int)ElsoElemszam.Value];
                    ElsoElemszam.Enabled = false;
                    for (int i = 0; i < Tomb_e.Length; i++)
                    {
                        Tomb_e[i] = new NumericUpDown()
                        {
                            Parent = this,
                            Minimum = 0,
                            Maximum = 30,
                            Size = new Size(50,25),
                            Location = new Point(20 + i*70, 120)
                        };
                        //Tomb_e[i].Enter += (s1, e2) => Tomb_e[i].Select(0, Tomb_e[i].Text.Length);
                    }
                    if (Tomb_e.Length > 9) Width = Tomb_e.Length * 70 + 20;
                    // Width = Tomb_e.Length * 80 + 20;
                    Tomb_e_elkeszult = new Button()
                    {
                        Parent = this,
                        Location = new Point(200,145),
                        Size = new Size(300,30),
                        Text = "Indísd az algoritmust"
                    };
                    Tomb_e_elkeszult.Click += (s2, e2) =>
                    {
                        int[] adatTomb_e = new int[Tomb_e.Length];
                        for (int i = 0; i < Tomb_e.Length; i++)
                        {
                            adatTomb_e[i] = (int)Tomb_e[i].Value;
                        }
                        alaptetel AT = new alaptetel(adatTomb_e);
                        Kiiras = new Label()
                        {
                            Parent = this,
                            Location = new Point(20, 200),
                            AutoSize = true,
                        };
                        
                        switch (MelyikTetel)
                        {
                            case "Összegzés":
                                AT.Osszegzes(); Kiiras.Text = "Összegzés eredménye" + AT.Osszegzes(); break;
                            case "Egyszerü cserés rendezés":
                                Kiiras.Text = TombElemekStringbe( AT.Egyszeru_Cseres()); break;
                            case "Buborékrendezés":
                                Kiiras.Text = TombElemekStringbe(AT.Buborek()); break; 
                            case "Shell beszúró rendezés":
                                Kiiras.Text = TombElemekStringbe(AT.Shell()); break;
                            case "Minimum-maximum rendezés":
                                Kiiras.Text = TombElemekStringbe(AT.MinMax()); break;
                        }
                        
                    };
                };
                //FomenuPontok[1].Enabled = true;
                Ok_gomb = new Button()
                {
                    Parent = this,
                    Text = "Ok",
                    Size = new Size(300, 30),
                    Location = new Point(200, 255)
                };
                Ok_gomb.Click += (s3, e3) => { Application.Restart(); };
            }
            else if (MitOlvasokBe=="té")
            {
                /*MasodikElemszam = new NumericUpDown()
                {
                    Parent = this,
                    Location = new Point(20, 50),
                    Minimum = 3,
                    Maximum = 15,
                };
                TT.SetToolTip(MasodikElemszam, "Add meg a tömb elemszámát!");*/
            }
            else
            {

            }
        }
        private string TombElemekStringbe(int[] T)
        {
            string duma = "";
            foreach (var elem in T)
            {
                duma += elem + " ";
            }
            return duma;
        }
        private void FomenuPont_Click(object sender, EventArgs e)
        {
            var aktualis = sender as ToolStripMenuItem;
            //leállítás
            if (aktualis.Text=="Kilépés")
            {
                Application.Exit();
            }
        }

        private void Fomenu_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
