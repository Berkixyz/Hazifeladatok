﻿using System;
using System.Linq;
using System.IO;

namespace OSZTV_1_konzol
{
    class Program //osztálynév
    {
        static int[][] Terkep; //tőmb, amely a térképet reprezentálja.
        static int Sorok, Oszlopok, MaxKulonbseg; // Ezek a változók tárolják a sorok és oszlopok számát, és a maximális megengedett érték különbségét.

        static void Main(string[] args) //A program belépési pontja
        {
            Beolvas(); //ez egy eljárás
            string leghosszabbut = ""; // Inicializálja egy üres stringet a leghosszabutat tarolja
            int maxhossz = 0, maxi = 0, maxj = 0; //Inicializálja a változókat 
            for (int i = 0; i < Sorok; i++)
            {
                for (int j = 0; j < Oszlopok; j++)
                {
                    string jelenlegi = LHO(i, j); //Meghívja a LHO függvényt a jelenlegi pozicioval
                    if (jelenlegi.Length > maxhossz) //megnézi, hogy az aktuális út hossza nagyobb e, mint a maximálisut, és ha igen, frissíti az értékeket.
                    {
                        maxhossz = jelenlegi.Length;
                        leghosszabbut = jelenlegi;
                        maxi = i;
                        maxj = j;
                    }
                }
            }
            Console.WriteLine(maxhossz);
            Console.WriteLine($"{maxi + 1} {maxj + 1}");
            Console.WriteLine(leghosszabbut);
            fajlbaIras(leghosszabbut,maxi,maxj);
			//kiírja a leghosszabbutat, pozícióját és magát az utat a konzolra, majd meghívja a fajlbaIras függvényt az adatok fájlba írásához.
        }

        static void fajlbaIras(string LegHosszabbUt,int sorindex, int oszlopindex)
        {
            /*"atadas.txt"-be írja az eredeti magasságpontokat,
             * és a megtalált útvonalat.*/
            var fajl = File.CreateText("atadas.txt");
            for (int s = 0; s < Sorok; s++)
            {
                string egysor = "";
                for (int o = 0; o < Oszlopok; o++)
                {
                    egysor += Terkep[s][o] + " " ;
                }
                egysor = egysor.Remove(egysor.Length - 1);      
                fajl.WriteLine(egysor);
            }
            fajl.WriteLine(sorindex + " " + oszlopindex);
            fajl.WriteLine(LegHosszabbUt);
            fajl.Close();
        }

        static string LHO(int s, int o, string utvonal = "") //Ez egy függvény, keresi a leghosszabbutat a terkepen az aktuális pozíciótól kezdve.
        {
            string[] iranyok = new string[] { "", "" }; //létrehoz egy új tömböt aminek van két üres indexe
            if (o < Oszlopok - 1 && Math.Abs(Terkep[s][o] - Terkep[s][o + 1]) <= MaxKulonbseg)
            {
                iranyok[0] = LHO(s, o + 1, utvonal + "J");
            }
            if (s < Sorok - 1 && Math.Abs(Terkep[s][o] - Terkep[s + 1][o]) <= MaxKulonbseg)
            {
                iranyok[1] = LHO(s + 1, o, utvonal + "L");
            }
            int ut_hossza = iranyok.Max(x => x.Length);
            if (ut_hossza == 0)
            {
                return utvonal;
            }
            return iranyok.First(x => x.Length == ut_hossza);
        }

        static void Beolvas() // ez egy eljárás
        {
            string[] data = Console.ReadLine().Split(' '); // konzolról olvassa be a bemásolt adatokat, Mi  vel az állomány első adata a sorok száma, ezt így tároljuk
            Sorok = int.Parse(data[0]);
            Oszlopok = int.Parse(data[1]); //a második adat az oszlopok száma
            MaxKulonbseg = int.Parse(data[2]); // az 1.sor 3. adata a lehetséges eltérés météke
            var input = new string[Sorok];// az input vátozó tartalmazz  többi sort
            for (int i = 0; i < Sorok; i++) // beolvassuk a többi sort
            {
                input[i] = Console.ReadLine().Trim(); // az eleje vége félesegeket eltávolitjuk
            }
            //a fogasléces tároló tömböt feltöltjük. A sorokat, amiket tömbként beletöltünk
            //a szoközök mentén felszeleteljuk majd a y -> int.Parse(y) hozzárendeléssel
            //tömbbé alakítjuk(ez egy LINQ utasitassal)
            Terkep = Enumerable.Range(0, Sorok).Select(x => input[x].Split(' ').Select(y => int.Parse(y)).ToArray()).ToArray();
        }
    }
}
///namespace OSZTV_1_konzol // névtér
///class Program //osztálynév
///static int[][] Terkep; //tőmb, amely a térképet reprezentálja.
///static int Sorok, Oszlopok, MaxKulonbseg; // Ezek a változók tárolják a sorok és oszlopok számát, és a maximális megengedett érték különbségét.
///static void Main(string[] args) //A program belépési pontja        
///Beolvas(); //ez egy eljárás
///string leghosszabbut = ""; // Inicializálja egy üres stringet a leghosszabutat tarolja
///int maxhossz = 0, maxi = 0, maxj = 0; //Inicializálja a változókat 
///string jelenlegi = LHO(i, j); //Meghívja a LHO függvényt a jelenlegi pozicioval
///if (jelenlegi.Length > maxhossz) //megnézi, hogy az aktuális út hossza nagyobb e, mint a maximálisut, és ha igen, frissíti az értékeket.
                    ///{
                       /// maxhossz = jelenlegi.Length;
                        ///leghosszabbut = jelenlegi;
                        ///maxi = i;
                        ///maxj = j;
                    ///}
                ///}
            ///}
            ///Console.WriteLine(maxhossz);
            ///Console.WriteLine($"{maxi + 1} {maxj + 1}");
            ///Console.WriteLine(leghosszabbut);
            ///fajlbaIras(leghosszabbut, maxi, maxj);
            ///kiírja a leghosszabbutat, pozícióját és magát az utat a konzolra, majd meghívja a fajlbaIras függvényt az adatok fájlba írásához.
///static void fajlbaIras(string LegHosszabbUt, int sorindex, int oszlopindex)
        ///{
           /// /*"atadas.txt"-be írja az eredeti magasságpontokat,
             ///* és a megtalált útvonalat.*/
            ///var fajl = File.CreateText("atadas.txt");           
                ///fajl.WriteLine(egysor); //kiirja a fajlt
            ///}
            ///fajl.WriteLine(sorindex + " " + oszlopindex);
            ///fajl.WriteLine(LegHosszabbUt);
            ///fajl.Close(); // bezarja a fajlt
///static string LHO(int s, int o, string utvonal = "") //Ez egy függvény, keresi a leghosszabbutat a terkepen az aktuális pozíciótól kezdve.
                   /// string[] iranyok = new string[] { "", "" }; //létrehoz egy új tömböt aminek van két üres indexe           
///static void Beolvas() // ez egy eljárás
        ///{
           /// string[] data = Console.ReadLine().Split(' '); // konzolról olvassa be a bemásolt adatokat, Mi  vel az állomány első adata a sorok száma, ezt így tároljuk
            ///Sorok = int.Parse(data[0]);
            ///Oszlopok = int.Parse(data[1]); //a második adat az oszlopok száma
            ///MaxKulonbseg = int.Parse(data[2]); // az 1.sor 3. adata a lehetséges eltérés météke
            ///var input = new string[Sorok];// az input vátozó tartalmazz  többi sort
            ///for (int i = 0; i  Sorok; i++) // beolvassuk a többi sort
            ///{
               /// input[i] = Console.ReadLine().Trim(); // az eleje vége félesegeket eltávolitjuk
            ///}
            ///a fogasléces tároló tömböt feltöltjük. A sorokat, amiket tömbként beletöltünk
            ///a szoközök mentén felszeleteljuk majd a y -> int.Parse(y) hozzárendeléssel
            ///tömbbé alakítjuk(ez egy LINQ utasitassal)