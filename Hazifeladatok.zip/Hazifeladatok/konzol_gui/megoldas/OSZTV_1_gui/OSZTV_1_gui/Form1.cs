﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace OSZTV_1_gui///namespace //Ez egy névtér
{
    public partial class Form1 : Form
    {
        Button fajlHelye, szinezes;
        Label[][] Terkep;
        string fajlNev;
        Color[] Szinek;
        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load;
        }
        ///Form1_Load //A form 1 betöltésekkor megjelenít egy vezérlőt
        ///A form betöltésénél beállítja a betutipust és méretet az elhelyezkedést, a cimet. hatterszint,incilazialjuk a szinekbeolvasasa metodust 
        ///fajlHelye = new Button()//fajlhelye gomb beállításai
        private void Form1_Load(object sender, EventArgs e)
        {
            
            Szinek = szinekBeolvasasa();
            Font = new Font("Times", 14f);
            Location = new Point(10, 10);
            Text = "Útvonalkereső";
            ClientSize = new Size(300, 50);
            BackColor = Szinek[0];

            fajlHelye = new Button() 
            {
                Parent = this,
                Location = new Point(10, 10),
                Size = new Size(ClientSize.Width - 20, ClientSize.Height - 20),
                Text = "Az átadott fájl helye",
                BackColor = Szinek[1]
            };
            fajlHelye.Click += FajlHelye_Click;
        }
        ///FajlHelye_Click  //ez egy metodus ami beolvassa a txt-t
        ///if (ofd.ShowDialog() == DialogResult.OK) //Vizsgálat hogy a beolvasott txt megeggyezik az eredménnyel
        ///Ha igen a fajl helyet elrejtjuk,a fajl nevet beáálitjuk a megnyitott fajl nevere, meghivjuk a terkepcimzes metodust
        /// fajlHelye.Hide(); //fajlhelyenek elrejtése
        ///TerkepCimzese(); meghívása
        ///else goto kezdes; //különben kidobb a kezdésre
        private void FajlHelye_Click(object sender, EventArgs e)
        {
        kezdes:OpenFileDialog ofd = new OpenFileDialog();
            ofd.Multiselect = false;
            ofd.Filter = "txt files (*.txt)|*.txt";
            if (ofd.ShowDialog() == DialogResult.OK)
               
            {
                fajlHelye.Hide(); 
                fajlNev = ofd.FileName;
                TerkepCimzese();
				
            }
            else goto kezdes;
        }
        ///szinezes_Click//ez egy metodus ami a szinezes:Click eseménynél történik meg.Kicsereli a hatter szint es a betuszinet az utvonalnak
        private void szinezes_Click(object sender, EventArgs e, string[] Sorok)
        {
            var csere = szinezes.BackColor;
            szinezes.BackColor = szinezes.ForeColor;
            szinezes.ForeColor = csere;
            UtvonalSzinezes(Sorok);
        }
        ///szinekBeolvasasa()//Ez a függvény szövegfájlból olvassa be a színeket és tárolja azokat egy tömbben.
        ///színeket olvassa be fájlból
        ///színeket átkonvertálja spaceel tördeli
        ///háttér beállítása rgb szerint
        ///színek átkonvertálása
        ///cimke hatter beallitasa
        ///cimkeszin atkonvertalasa
        ///szintem maradt szin beallitasa
        ///színek átkonvertálása
        ///lefele szin beallitasa
        ///színek átkonvertálása
        /// felfele szin beallitasa
        Color[] szinekBeolvasasa()
        {
            var szinek = File.ReadAllLines("szinek.txt"); 
            int[] szinRGB = Array.ConvertAll(szinek[0].Split(';'), int.Parse); //
            Color hatter = Color.FromArgb(szinRGB[0], szinRGB[1], szinRGB[2]); //
            szinRGB = Array.ConvertAll(szinek[1].Split(';'), int.Parse); //
            Color cimkehatter = Color.FromArgb(szinRGB[0], szinRGB[1], szinRGB[2]); //
            szinRGB = Array.ConvertAll(szinek[2].Split(';'), int.Parse); //
            Color szintenmarad = Color.FromArgb(szinRGB[0], szinRGB[1], szinRGB[2]); //
            szinRGB = Array.ConvertAll(szinek[3].Split(';'), int.Parse); //
            Color lefele = Color.FromArgb(szinRGB[0], szinRGB[1], szinRGB[2]); // 
            szinRGB = Array.ConvertAll(szinek[4].Split(';'), int.Parse); //
            Color felfele = Color.FromArgb(szinRGB[0], szinRGB[1], szinRGB[2]); //
            return new Color[] { hatter, cimkehatter, szintenmarad, lefele, felfele};
        }
        ///  Reszponzivitas() Ez a függvény állítja be az űrlap méretét és a címkék betűméretét a tartalom alapján.
        void Reszponzivitas(string[] sorok, ref float cBM, ref int cSz, ref int cM, ref int cK) 
        {
            #region előzetes label méret számolások (reszponzív kód)
            if (sorok[0].Split(' ').Length <= 10 && (sorok.Length - 2) <= 10)
            {
                cSz = 60; cM = 60; cK = 10;
                cBM = this.Font.Size * 1.4f;
            }
            else if (sorok[0].Split(' ').Length <= 25 && (sorok.Length - 2) <= 25)
            {
                cSz = 35; cM = 30; cK = 5;
                cBM = this.Font.Size;
            }
            else if (sorok[0].Split(' ').Length <= 40 && (sorok.Length - 2) <= 40)
            {
                cSz = 25; cM = 20; cK = 3;
                cBM = this.Font.Size / 1.4f;
            }
            else if (sorok[0].Split(' ').Length <= 60 && (sorok.Length - 2) <= 60)
            {
                cSz = 22; cM = 16; cK = 2;
                cBM = this.Font.Size / 1.6f;
            }
            int xMeret = sorok[0].Split(' ').Length, yMeret = sorok.Length - 2;
            ClientSize = new Size((xMeret) * cSz + (xMeret + 1) * cK, (yMeret + 1) * cM + (yMeret + 5) * cK);
            #endregion
        }
        ///TerkepCimzese() //Ez a függvény inicializálja a térképet, létrehozva címkéket az űrlapon a szövegfájl tartalma alapján.
        private void TerkepCimzese() //Ez a függvény inicializálja a térképet, létrehozva címkéket az űrlapon a szövegfájl tartalma alapján.
        {
            string[] sorok = File.ReadAllLines(fajlNev);
            Terkep = new Label[sorok.Length - 2][];
            float cimkeBetuMeret = 0;
            int cimkeSzelesseg = 0, cimkeMagassag = 0, cimkeKoz = 0;
            //reszponzív rész hívása:
            Reszponzivitas(sorok, ref cimkeBetuMeret, ref cimkeSzelesseg, ref cimkeMagassag, ref cimkeKoz);

            for (int s = 0; s < sorok.Length-2; s++)
            {
                var egysor = sorok[s].Split(' ');
                Terkep[s] = new Label[egysor.Length];
                for (int o = 0; o < egysor.Length; o++)
                {
                    Terkep[s][o] = new Label()
                    {
                        Parent = this,
                        Size = new Size(cimkeSzelesseg, cimkeMagassag),
                        Font = new Font("Times", cimkeBetuMeret),
                        Location = new Point(o * cimkeSzelesseg + (1 + o) * cimkeKoz, s * cimkeMagassag + (s + 1) * cimkeKoz),
                        Text = egysor[o],
                        BackColor = Szinek[1],
                        TextAlign = ContentAlignment.MiddleCenter
                    };
                }                
            }
            ///Ez egy gomb beallitasai ami a leghosszabbut szinezest, betustilusat, szövegét állítja be
            szinezes = new Button() 
            {
                Parent = this,
                Location = new Point(10, ClientSize.Height - (cimkeMagassag + cimkeKoz*4)),
                Size = new Size(ClientSize.Width - 20, cimkeMagassag + cimkeKoz*3),
                Font = new Font("Times", cimkeBetuMeret),
                Text = "Jelöld ki az optimális utat!",
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Szinek[1]
            };
            szinezes.Click += (sender2, e2) => szinezes_Click(sender2, e2, sorok);

        }
        /// Ez a függvény színezi az útvonalat a térképen az adott útvonal alapján.
        private void UtvonalSzinezes(string[] sorok)
        {
            int kezdoX = int.Parse(sorok[sorok.Length - 2].Split(' ')[0]);
            int kezdoY = int.Parse(sorok[sorok.Length - 2].Split(' ')[1]);
            var utvonal = sorok[sorok.Length - 1].ToCharArray();
            //szinek[2]-szinten marad; szinek[3]-csökken a szint; szinek[4]-emelkedik
            Terkep[kezdoX][kezdoY].BackColor = Szinek[2];
            for (int i = 0; i < utvonal.Length; i++)
            {
                if (utvonal[i] == 'L')
                {
                    kezdoX++;
                    if (int.Parse(Terkep[kezdoX - 1][kezdoY].Text) == int.Parse(Terkep[kezdoX][kezdoY].Text))
                        Terkep[kezdoX][kezdoY].BackColor = Szinek[2];
                    else if (int.Parse(Terkep[kezdoX - 1][kezdoY].Text) < int.Parse(Terkep[kezdoX][kezdoY].Text))
                        Terkep[kezdoX][kezdoY].BackColor = Szinek[4];
                    else Terkep[kezdoX][kezdoY].BackColor = Szinek[3];
                }
                else
                {
                    kezdoY++;
                    if (int.Parse(Terkep[kezdoX][kezdoY - 1].Text) == int.Parse(Terkep[kezdoX][kezdoY].Text))
                        Terkep[kezdoX][kezdoY].BackColor = Szinek[2];
                    else if (int.Parse(Terkep[kezdoX][kezdoY - 1].Text) < int.Parse(Terkep[kezdoX][kezdoY].Text))
                        Terkep[kezdoX][kezdoY].BackColor = Szinek[4];
                    else Terkep[kezdoX][kezdoY].BackColor = Szinek[3];
                }
            }

        }
    }
}
