﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hazi_Feladat
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void FindPalindromes(object sender, RoutedEventArgs e)
        {
            lstPalindromes.Items.Clear();

            if (int.TryParse(txtN.Text, out int n) && n > 0)
            {
                for (int i = 0; i <= n; i++)
                {
                    if (IsPalindrome(i))
                    {
                        lstPalindromes.Items.Add(i);
                    }
                }
            }
            else
            {
                MessageBox.Show("Kérem adjon meg egy érvényes pozitív egész számot!");
            }
        }

        private bool IsPalindrome(int number)
        {
            string numStr = number.ToString();
            int length = numStr.Length;
            for (int i = 0; i < length / 2; i++)
            {
                if (numStr[i] != numStr[length - i - 1])
                {
                    return false;
                }
            }
            return true;
        }
    }
}